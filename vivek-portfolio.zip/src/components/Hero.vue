<template>
  <section class="section fade hero">
    <h1>Hi, I'm <span class="highlight">Vivek Khanke</span></h1>
    <h2 class="role">Data Engineer</h2>

    <p class="desc">
      I design and build data pipelines on Azure Cloud, Databricks, and Oracle SQL.
      Skilled in ETL, Unix and modern data engineering tools.
    </p>

    <a href="/Vivek_Khanke_CV.pdf" download class="btn">Download CV</a>
  </section>
</template>

<style scoped>
</style>