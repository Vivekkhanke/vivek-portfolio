<template>
  <section class="section fade">
    <h2>Experience</h2>

    <div class="card">
      <h3>Data Engineer (4 Years)</h3>
      <p>
        Worked on Azure data platforms, ETL development, data migration, Delta Lake,
        and end-to-end pipeline creation using Databricks and SQL.
      </p>
      <p>
        Experience in building secure, scalable data solutions integrating ADLS Gen2,
        ADF, Databricks, and Oracle systems.
      </p>
    </div>
  </section>
</template>

<style scoped>
p{line-height:1.6;margin:10px 0}
</style>