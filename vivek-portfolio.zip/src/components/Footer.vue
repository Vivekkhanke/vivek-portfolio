<template>
  <footer class="footer fade">
    © 2025 Vivek Khanke — All Rights Reserved
  </footer>
</template>

<style scoped>
</style>