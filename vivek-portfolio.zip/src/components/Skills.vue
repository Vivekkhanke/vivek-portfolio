<template>
  <section class="section fade">
    <h2>Skills</h2>

    <div class="card">
      <div class="skills-list">
        <span class="skill-pill">Azure Cloud</span>
        <span class="skill-pill">ETL</span>
        <span class="skill-pill">Oracle SQL</span>
        <span class="skill-pill">PL/SQL</span>
        <span class="skill-pill">Databricks</span>
        <span class="skill-pill">Unix</span>
      </div>
    </div>
  </section>
</template>

<style scoped>
.skill-pill{ font-size:15px }
</style>