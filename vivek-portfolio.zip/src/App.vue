<template>
  <Hero />
  <Skills />
  <Experience />
  <Footer />
</template>

<script setup>
import Hero from './components/Hero.vue'
import Skills from './components/Skills.vue'
import Experience from './components/Experience.vue'
import Footer from './components/Footer.vue'
</script>